import {env} from 'cloudflare:workers';
export function database(){if(!env.DB)throw Error('Database unavailable');return env.DB;}
export function respond(payload:unknown,status=200){return Response.json(payload,{status,headers:{'Access-Control-Allow-Origin':'https://blue-jay-sun.github.io','Vary':'Origin','Cache-Control':'no-store'}});}
export function failure(error:unknown){console.error('Database failure',error);return respond({success:false,message:'数据库暂时不可用，请稍后重试'},503);}
export function OPTIONS(){return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':'https://blue-jay-sun.github.io','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}});}

import {database,respond,failure} from '@/lib/api';
export {OPTIONS} from '@/lib/api';
export async function GET(request:Request){const url=new URL(request.url),raw=url.searchParams.get('page')||'1',page=Number(raw),q=(url.searchParams.get('q')||'').slice(0,500);if(!/^\d+$/.test(raw)||!Number.isInteger(page)||page<1||page>1000000)return respond({success:false,message:'页码无效'},400);
try{const db=database();const results=await db.batch([db.prepare('SELECT count(*) AS total FROM history WHERE instr(expression,?)>0').bind(q),db.prepare('SELECT * FROM history WHERE instr(expression,?)>0 ORDER BY id DESC LIMIT 10 OFFSET ?').bind(q,(page-1)*10)]);return respond({success:true,items:results[1].results,total:results[0].results[0].total,page,page_size:10});}catch(error){return failure(error);}}

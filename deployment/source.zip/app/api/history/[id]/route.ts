import {database,respond,failure} from '@/lib/api';
export {OPTIONS} from '@/lib/api';
export async function DELETE(_request:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params;if(!/^\d+$/.test(id)||BigInt(id)<1n||BigInt(id)>BigInt(Number.MAX_SAFE_INTEGER))return respond({success:false,message:'记录编号无效'},400);try{const removed=await database().prepare('DELETE FROM history WHERE id=?').bind(Number(id)).run();return respond({success:removed.meta.changes>0,message:removed.meta.changes?'已删除':'记录不存在'},removed.meta.changes?200:404);}catch(error){return failure(error);}}

import {respond,database,failure} from '@/lib/api';
export async function GET(){try{await database().prepare('SELECT 1 FROM history LIMIT 1').all();return respond({success:true});}catch(error){return failure(error);}}

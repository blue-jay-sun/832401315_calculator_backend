import {calculate} from '@/lib/calculator.mjs';
import {database,respond,failure} from '@/lib/api';
export {OPTIONS} from '@/lib/api';
export async function POST(request:Request){
 let expression:string,result:string;
 try{const body=await request.text();if(new TextEncoder().encode(body).length>4096)throw Error('请求过大');const data=JSON.parse(body);if(!data||typeof data!=='object'||Array.isArray(data))throw Error('请求必须是 JSON 对象');result=calculate(data.expression);expression=data.expression.trim();}catch(error){return respond({success:false,message:error instanceof Error?error.message:'请求无效'},400);}
 try{const created_at=new Date().toISOString();const inserted=await database().prepare('INSERT INTO history(expression,result,created_at) VALUES(?,?,?)').bind(expression,result,created_at).run();return respond({success:true,id:inserted.meta.last_row_id,expression,result,created_at},201);}catch(error){return failure(error);}
}

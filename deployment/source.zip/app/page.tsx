export default function Home(){return <iframe title="清算计算器" src="/calculator/index.html" style={{position:"fixed",inset:0,width:"100%",height:"100%",border:0}}/>;}

window.CALCULATOR_API = '';

CREATE TABLE `history` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`expression` text NOT NULL,
	`result` text NOT NULL,
	`created_at` text NOT NULL
);
